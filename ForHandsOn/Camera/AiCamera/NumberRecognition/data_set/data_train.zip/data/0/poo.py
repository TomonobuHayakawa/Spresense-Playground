import numpy as np
from PIL import Image
import random

def add_gaussian_noise(image, mean=0, sigma=5):
    np_image = np.array(image)
    noise = np.random.normal(mean, sigma, np_image.shape).astype('uint8')
    noisy_image = np_image + noise
    noisy_image = np.clip(noisy_image, 0, 100)
    noisy_image_pil = Image.fromarray(noisy_image.astype('uint8'))

    return noisy_image_pil

image = Image.open("000.png")

noisy_image = add_gaussian_noise(image)

noisy_image.save("001.png")
